﻿namespace Day4
{
    class Day4
    {
        public static void Main(string[] args)
        {
            #region Problem 1
            //--1
            //---1.1
            //int[] arr = new int[3];
            //arr[0] = 1;
            //arr[1] = 2;
            //arr[2] = 3;
            //---1.2
            //int[] arr = new int[] { 1, 2, 3 };
            //---1.3
            //int[] arr = { 1, 2, 3 };
            //IndexOutOfRangeException occur when i try to access an index is greater then or equal the array size or less than zero like:
            //Console.WriteLine(arr[3]);
            //Console.WriteLine(arr[-1]);
            //the default value assigned to array elements is:
            //int, float, double, decimal, byte => 0
            //bool => false
            //string => empty string ""
            //char => empty '' 
            #endregion

            #region Problem 2
            //--2
            //int[] arr1 = { 3, 2, 4, 1 };
            //int[] arr2 = { 6, 5, 8, 7 };
            //shallow copy
            //arr2 = arr1;
            //Console.WriteLine(arr2[0]);
            ////in shallow copy the changes in arr2 affects on arr1 (because arr1 and arr2 pointer to the same location in the memory)
            //arr2[0] = 9;
            //Console.WriteLine(arr1[0]);

            //deep copy
            //arr2 = (int[])arr1.Clone();
            ////in deep copy the changes in arr2 don't affects on arr1 (because Clone() create a new copy from arr1 in different location in memory)
            //Console.WriteLine(arr2[0]);
            //arr2[0] = 9;
            //Console.WriteLine(arr1[0]);

            //Array.Clone(): Creates a shallow copy of the array and returns a new array object.
            //Array.Copy(): Copies elements into a pre-existing array with more control over what and where to copy. 
            #endregion

            #region Problem 3
            //--3
            //int[,] grades = new int[3,3];
            //for (int i = 0; i < grades.GetLength(0); i++)
            //{
            //    for (int j = 0; j < grades.GetLength(1); j++)
            //    {
            //        Console.Write($"Enter student {i + 1} subject {j + 1} grade: ");
            //        grades[i,j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //Console.WriteLine("Student No. sub1 sub2 sub3");
            //for (int i = 0; i < grades.GetLength(0); i++)
            //{
            //    Console.Write($"Student {i + 1}".PadRight(12));
            //    for (int j = 0; j < grades.GetLength(1); j++)
            //    {
            //        Console.Write($"{grades[i, j]}".PadRight(5));
            //    }
            //    Console.WriteLine();
            //}

            ////GetLength(): Retrieves the size of a specific dimension in a multidimensional array.
            ////Length: Retrieves the total number of elements in the entire array 
            #endregion

            #region Problem 4
            //--4
            //int[] arr = { 4, 3, 6, 5, 8, 9, 1, 7, 2 };

            //Sort
            //Array.Sort(): Sort the array in ascending order
            //Array.Sort(arr);

            //Reverse
            //Array.Reverse(array): Reverse the order of the elements
            //Array.Reverse(arr);

            //IndexOf
            //Array.IndexOf(array, element): Take the array and the element you want to find its index as parameter and return the index of this element (if element does not exist return -1)
            //Console.WriteLine(Array.IndexOf(arr, 4));

            //Copy
            //Array.Copy(sourceArray, destinationArray, size): Copy the first size element from sourceArray to destinationArray
            //int[] arrTwo = { 13, 11, 16, 18, 14, 12, 19, 15, 17 };
            //Array.Copy(arrTwo, arr, 3);

            //Clear
            //Array.Clear(array): Clear the array elements
            //Array.Clear(arr);
            //Array.Clear(array, startIndx, length): Start from startIndx and clear length elements
            //Array.Clear(arr, 0, 3);

            //Print the array
            //Console.Write("[");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (i != arr.Length - 1)
            //    {
            //        Console.Write($"{arr[i]}, ");
            //    }
            //    else
            //    {
            //        Console.Write(arr[i]);
            //    }
            //}
            //Console.WriteLine("]");

            //Array.Copy() is the most commonly used method for copying elements between arrays. It’s fast, flexible, and works in most scenarios.
            //Array.ConstrainedCopy() is a more specialized method used when type safety and bounds checking are required, often in unsafe contexts or when working with 
            #endregion interop scenarios.

            #region Problem 5
            //--5
            //int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            ////for
            //Console.Write("[");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (i != arr.Length - 1)
            //    {
            //        Console.Write($"{arr[i]}, ");
            //    }
            //    else
            //    {
            //        Console.Write(arr[i]);
            //    }
            //}
            //Console.WriteLine("]");

            //Console.Write("[ ");
            //foreach (int item in arr)
            //{
            //    Console.Write($"{item} ");
            //}
            //Console.WriteLine("]");

            ////while
            //int j = arr.Length - 1;
            //Console.Write("[");
            //while (j >= 0)
            //{
            //    if (j != 0)
            //    {
            //        Console.Write($"{arr[j]}, ");
            //    }
            //    else
            //    {
            //        Console.Write(arr[j]);
            //    }
            //    j--;
            //}
            //Console.WriteLine("]");
            //Console.WriteLine(arr[100]);
            ////Why is foreach preferred for read-only operations on arrays?
            ////1. Readble and simple
            ////2. Safety from modification
            ////3. Avoiding IndexOutOfRangeException
            ////4. Performance (no index calculator like i++)
            #endregion

            #region Problem 6
            //--6
            //int number;
            //bool flag = true;

            //do
            //{
            //    Console.Write("Enter a positive odd number: ");
            //    flag = int.TryParse(Console.ReadLine(), out number);
            //}
            //while (!flag || number % 2 == 0 || number <= 0);
            //Console.WriteLine($"Positive odd number = {number}");

            ////Input validation is important because the user input can throw an exception 
            #endregion

            #region Problem 7
            ////--7
            //int[,] arr =
            //{
            //    { 1 ,2, 3 },
            //    { 4, 5, 6 },
            //    { 7, 8, 9 }
            //};

            //for (int i = 0; i < arr.GetLength(0); i++)
            //{
            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        Console.Write($"{arr[i, j]}  ");
            //    }
            //    Console.WriteLine();
            //}

            ////To format the output of a 2D array for better readability we can use:
            ////1. ToString() and PadLeft() or PadRight()
            ////2. use tab => \t
            ////3. Use Custom Formatting for Numbers => ToString("F2") 
            #endregion

            #region Problem 8
            ////--8
            //int monthNumber;
            //bool flag = true;
            //do
            //{
            //    Console.Write("Enter month number: ");
            //    flag = int.TryParse(Console.ReadLine(), out monthNumber);
            //}
            //while (!flag);

            //if (monthNumber == 1)
            //{
            //    Console.WriteLine("January");
            //}
            //else if (monthNumber == 2)
            //{
            //    Console.WriteLine("February");
            //}
            //else if (monthNumber == 3)
            //{
            //    Console.WriteLine("March");
            //}
            //else if (monthNumber == 4)
            //{
            //    Console.WriteLine("April");
            //}
            //else if (monthNumber == 5)
            //{
            //    Console.WriteLine("May");
            //}
            //else if (monthNumber == 6)
            //{
            //    Console.WriteLine("June");
            //}
            //else if (monthNumber == 7)
            //{
            //    Console.WriteLine("July");
            //}
            //else if (monthNumber == 8)
            //{
            //    Console.WriteLine("August");
            //}
            //else if (monthNumber == 9)
            //{
            //    Console.WriteLine("September");
            //}
            //else if (monthNumber == 10)
            //{
            //    Console.WriteLine("October");
            //}
            //else if (monthNumber == 11)
            //{
            //    Console.WriteLine("November");
            //}
            //else if (monthNumber == 12)
            //{
            //    Console.WriteLine("December");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid month number");
            //}


            //switch (monthNumber)
            //{
            //    case 1:
            //        Console.WriteLine("January");
            //        break;
            //    case 2:
            //        Console.WriteLine("February");
            //        break;
            //    case 3:
            //        Console.WriteLine("March");
            //        break;
            //    case 4:
            //        Console.WriteLine("April");
            //        break;
            //    case 5:
            //        Console.WriteLine("May");
            //        break;
            //    case 6:
            //        Console.WriteLine("June");
            //        break;
            //    case 7:
            //        Console.WriteLine("July");
            //        break;
            //    case 8:
            //        Console.WriteLine("August");
            //        break;
            //    case 9:
            //        Console.WriteLine("September");
            //        break;
            //    case 10:
            //        Console.WriteLine("October");
            //        break;
            //    case 11:
            //        Console.WriteLine("November");
            //        break;
            //    case 12:
            //        Console.WriteLine("December");
            //        break;
            //    default:
            //        Console.WriteLine("Invalid month number");
            //        break;
            //}

            ////We prefer a switch statement over if-else when:
            ////1. You have multiple discrete values to compare
            ////2. You are comparing a single expression against multiple constant values
            ////3. You are dealing with Enums
            ////4. You want a more structured and easy-to-maintain solution 
            #endregion

            #region Problem 9
            ////--9
            //int[] arr = { 4, 2, 6, 8, 3, 7, 7, 1, 9, 5, 7 };

            ////Sort
            //Array.Sort(arr);
            //Console.Write("[");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (i != arr.Length - 1)
            //    {
            //        Console.Write($"{arr[i]}, ");
            //    }
            //    else
            //    {
            //        Console.Write(arr[i]);
            //    }
            //}
            //Console.WriteLine("]");

            ////IndexOf(array, element): Return the first index with value = element from array
            //Console.WriteLine(Array.IndexOf(arr, 7));
            ////LastIndexOf(array, element): Return the last index with value = element from array
            //Console.WriteLine(Array.LastIndexOf(arr, 7));

            ////Array.Sort() time complexity (depends on used algorithm to sort):
            ////1. With Primitive Types => use Dual-Pivot Quicksort, time complexity:
            ////  - Best and Average case: O(n logn)
            ////  - Worsc case: O(n^2)
            ////2. With Reference Types => use TimeSort, time complexity:
            ////  - Best case: O(n)
            ////  - Average and Worst case: O(n logn) 
            #endregion

            #region Problem 10
            ////--10
            //int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //int sum = 0;

            ////for
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    sum += arr[i];
            //}
            //Console.WriteLine(sum);

            //sum = 0;

            ////foreach
            //foreach (int item in arr)
            //{
            //    sum += item;
            //}
            //Console.WriteLine(sum);

            ///*
            // * for is more efficient:
            // *      The for loop allows you to work directly with the index, and there is no need to create an enumerator or iterator,
            // *      which can add a small overhead in the foreach loop.
            //*/ 
            #endregion

            #region Part 2
            ////Part 2
            ////--2.2
            //Console.Write("Enter day number: ");
            //int day = int.Parse(Console.ReadLine());

            //Console.WriteLine(Enum.Parse(typeof(DayOfWeeks), day.ToString()));

            ////2.3
            ////If the user enters a value outside the range of 1 to 7 the program will print this number 
            #endregion

        }
    }
    
    #region Part 2 Enum
    ////Part 2
    //enum DayOfWeeks
    //{
    //    Monday = 1,
    //    Tuesday,
    //    Wednesday,
    //    Thursday,
    //    Friday,
    //    Saturday,
    //    Sunday
    //} 
    #endregion
}